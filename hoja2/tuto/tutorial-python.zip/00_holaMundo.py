print('hola mundo!')

































# mi primer programa -> ejecutar en intérprete
#print('hola mundo!')


# más programa (descomentar)
x = 2+2
print(x)


# También podemos arrancar el intérprete en línea de comandos ... y ejecutar instrucciones

# Y también podemos utilizar notebooks (Jupyter), muy útiles para aprender el lenguaje



